#include "image_di.h"

#define ByPP 4
#define BiPP 32
#define MkStr(X) X##32
#define MkStrB(X) X##32bpp

#define Colortype unsigned int

#include "image_di_Xbpp.h"
#include "image_di_Xbpp.cc"
