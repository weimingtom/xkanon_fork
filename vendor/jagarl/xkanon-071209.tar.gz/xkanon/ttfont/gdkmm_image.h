/*-
 * @(#)gdkmm_image.h -- Gdk--'s Gdk_Image with TrueType font and some extended methods
 */

#ifndef _GDKMM_IMAGE_FREETYPE_H
#define _GDKMM_IMAGE_FREETYPE_H

#include <gdk--/image.h>

#include "gdkmm_font.h"

class Gdk_Image_FreeType : public Gdk_Image {
protected:
    /* get chars array filled with font bitmap */
    char *get_bitmap(Gdk_Font_FreeType &, int, int &, int &) const;

public:
    /* constructors */
    Gdk_Image_FreeType() {}
    Gdk_Image_FreeType(GdkImageType, Gdk_Visual &, gint, gint);
    Gdk_Image_FreeType(const Gdk_Image& image);

    /* destructor */
    virtual ~Gdk_Image_FreeType();

    /* draw text using freetype */
    void draw_marged_text(Gdk_Font_FreeType &, gint, gint, gint, guint32);

    /* copy image from other image */
    void draw_image(Gdk_Image &, gint, gint, gint, gint, gint = -1, gint = -1);
void Free(void) { obj_=0;}
};

#endif

/* gdkmm_image.h ends here */
