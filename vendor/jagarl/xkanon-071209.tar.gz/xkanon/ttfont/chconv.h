/*-
 * @(#)chconv.h -- Kanji converter
 */

#ifndef _CHCONV_H
#define _CHCONV_H

unsigned int chconv_null(unsigned int);

unsigned int chconv_euc_to_jis(unsigned int);
unsigned int chconv_jis_to_unicode(unsigned int);
unsigned int chconv_euc_to_unicode(unsigned int);

unsigned int chconv_unicode_to_jis(unsigned int);
unsigned int chconv_jis_to_euc(unsigned int);
unsigned int chconv_unicode_to_euc(unsigned int);

unsigned int chconv_jis_to_sjis(unsigned int);
unsigned int chconv_euc_to_sjis(unsigned int);

unsigned int chconv_sjis_to_jis(unsigned int);
unsigned int chconv_sjis_to_euc(unsigned int);

#endif

/* chconv.h ends here */
