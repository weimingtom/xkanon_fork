/*-
 * @(#)gdkmm_pixmap.h -- Gdk--'s Gdk_Pixmap with TrueType font
 */

#ifndef _GDKMM_PIXMAP_FREETYPE_H
#define _GDKMM_PIXMAP_FREETYPE_H

#include <gdk--/pixmap.h>

#include "gdkmm_font.h"

class Gdk_Pixmap_FreeType : public Gdk_Pixmap {
public:
    /* constructors */
    Gdk_Pixmap_FreeType() {}
    Gdk_Pixmap_FreeType(const Gdk_Drawable &, gint, gint, gint = -1);

    /* destructor */
    virtual ~Gdk_Pixmap_FreeType();

    /* overrided draw_string() */
    void draw_string(Gdk_Font_FreeType &, Gdk_GC &, gint, gint, const Gtk::string &);
};

#endif

/* gdkmm_pixmap.h ends here */
