/* itest_main.cc
 *    ����ե��å��ط��Υƥ����ѡ�
 */
/*
 *
 *  Copyright (C) 2000-   Kazunori Ueno(JAGARL) <jagarl@creator.club.ne.jp>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
*/

#if 0
#include <gtk--/main.h>
#include <gtk--/window.h>
#include <gtk--/button.h>
#include <gtk--/pixmap.h>
#include <gtk--/box.h>
#include <gtk--/packer.h>
#include <gtk--/menu.h>
#include <gtk--/label.h>
#include <gtk--/eventbox.h>
#include <gtk--/fixed.h>
#include <glib.h>
#include <X11/Xlib.h>
#include <gdk/gdkx.h>
#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<signal.h>
#endif
#include<stdio.h>
#include<stdlib.h>
#include"initial.h"
#include"system.h"
#include<gdk/gdk.h>


static int is_quit = 0;
#include<pthread.h>
void QuitAll(void)
{
	global_system.Finalize();
	// gtk_main_quit();
}
// �����ʥ��̵�뤹��
static void null_signal_handler(int sig_num) {
	is_quit = 1;
}
static void alarm_signal_handler(int sig_num) {
}

// �����ƥ��λ����
static void signal_handler(int sig_num) {
	global_system.Finalize();
}

static void signal_handler_segv(int sig_num) {
	fprintf(stderr, "Segmentation Fault.");
	if (is_quit) abort(); // ������λ
	is_quit = 1;
	global_system.Finalize();
	global_system.FinalizeMusic(); // ������λ�����ڥץ�����
//	gtk_main_quit();
	exit(0);
}

void SaveFile(int n) {}
int main(int argc, char *argv[])
{
	Initialize::Exec();
	// �Ȥꤢ�����������ʥ��̵���ˤ��Ƥ���
	signal(SIGINT, null_signal_handler);
	signal(SIGTERM, null_signal_handler);

//	gtk_set_locale();

#ifdef DEFAULT_DATAPATH
	char* datpath = DEFAULT_DATAPATH;
#else
	char* datpath = "/tmp/kanon";
#endif

#ifdef DEFAULT_SAVEPATH
	char* savepath = DEFAULT_SAVEPATH;
#else
	char* savepath = "~/.kanon";
#endif

	global_system.SetDatPath(datpath);
	global_system.SetSavePath(savepath);
	// config �ե�������ɤ߹���
	char buf[1024]; strcpy(buf, datpath); int len = strlen(buf);
	if (buf[len-1] != DIR_SPLIT) buf[len++] = DIR_SPLIT;
	strcpy(buf+len, "gameexe.ini");
	// ¸�߳�ǧ
	FILE* in = fopen_without_caps(buf,"r");
	if (in == 0) {
		fprintf(stderr, "Cannot open ini file : %s\n", buf);
		return -1;
	}
	fclose(in);
	global_system.LoadInitFile(buf);
	gdk_init(&argc, &argv);
GdkVisual* vis = gdk_visual_get_system();
printf("%x\n",vis);
#if 0

	Gtk::Main* kit = new Gtk::Main(argc, argv);
	if (fontname == fontname_orig && fontsize != 0) {
		fontname = buf;
		sprintf(buf, "-*-*-*-r-*--%d-*-*-*-*-*-jisx0208.1983-*", fontsize);
	}
	AyuWindow* view = new AyuWindow(global_system, fontname);
	if (fontsize != 0) view->SetFontSize(fontsize);
	
	int point;

	Gtk::Main::timeout.connect(SigC::slot(timer),100);

        kit->run();  // ��λ����ˤ� ^C ����ɬ�פ����롣

	/* ���Ѥ������������ʬ�� return ���˲������Ƥ���
	** (memory profiling ��)
	*/
	delete view;
#endif

        return(0);
}
