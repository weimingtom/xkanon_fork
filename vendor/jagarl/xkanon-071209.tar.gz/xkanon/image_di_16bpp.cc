#include "image_di.h"

#define ByPP 2
#define BiPP 16
#define MkStr(X) X##16
#define MkStrB(X) X##16bpp

#define Colortype unsigned short

#include "image_di_Xbpp.h"
#include "image_di_Xbpp.cc"
